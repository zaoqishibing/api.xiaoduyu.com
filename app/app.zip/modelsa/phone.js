
import { Phone } from '../schemas'
import baseMethod from './base-method'

let Schemas = new baseMethod(Phone)

module.exports = Schemas;
