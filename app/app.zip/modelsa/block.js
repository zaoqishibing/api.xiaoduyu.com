
import { Block } from '../schemas'
import baseMethod from './base-method'

let Schemas = new baseMethod(Block)

module.exports = Schemas
