
import { Report } from '../schemas'
import baseMethod from './base-method'

const Schemas = new baseMethod(Report)

module.exports = Schemas
