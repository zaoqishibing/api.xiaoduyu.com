import { Account } from '../schemas';
import baseMethod from './base-method';

module.exports = new baseMethod(Account);
